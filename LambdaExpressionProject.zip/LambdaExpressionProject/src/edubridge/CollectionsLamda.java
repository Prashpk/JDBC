package edubridge;

import java.util.ArrayList;

public class CollectionsLamda {

	public static void main(String[] args) {

		ArrayList<Integer> l =new ArrayList<Integer>();
		l.add(5);
		l.add(6);
		l.add(8);
		l.add(9);
		l.add(3);
		
		//for each Lambda Expression
		l.forEach( (n)-> System.out.println(n) );//Iterating list using Lambda
		
	}

}
