package edubridge;

@FunctionalInterface
interface Drawable1
{
	//An Interface having Single Abstract Method 
	void draw();//Lambda Expressions can be applied to Functional interfaces
         //Method with no return type and no arguements
}

@FunctionalInterface
interface Sayable{
	void say(String s); //function with arg with no return type 
}

@FunctionalInterface
interface SayableReturnType{
	String sayHello(); //function with return type with no arg
}

@FunctionalInterface
interface Addition{
	int add(int a, int b); //function with return type & arg
}

public class LambdaClassMain {

	public static void main(String[] args) {
		
		Drawable1 dob = ()->{
		 System.out.println("draw method body");
		};
		dob.draw();

		
		Sayable sob = (String s)->{
			System.out.println("Hello "+s);
		};
		sob.say("savitri");
		
		SayableReturnType sb = ()->{
			return "Hi";
//			String res = "hello my name is"; 
//			return res;
		};
		System.out.println(sb.sayHello());
		
		Addition ad = (int i,int j)->{
			int s = i + j;
			return s;
		};
		System.out.println(ad.add(10, 20));
		
		//similar Way But easier we can use Lambda 
		Addition aob =(i,j)->(i+j);
		System.out.println(aob.add(30, 50));
		
	}

}
