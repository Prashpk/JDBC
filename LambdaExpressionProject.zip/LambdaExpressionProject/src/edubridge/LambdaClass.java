package edubridge;

@FunctionalInterface
interface Drawable
{
	//An Interface having Single Abstract Method 
	void draw();//Lambda Expressions can be applied to Functional interfaces

}

public class LambdaClass {
/*
	@Override
	public void draw() {
		System.out.println("Draw MEthod");
		
	}
	*/
	public static void main(String[] args) {

		/*
		//Anonymus Class
    Drawable ob = new Drawable() {
		
	@Override
	public void draw() {
		System.out.println("I am Draw Method");
		
	}
		};
		ob.draw();
		*/
		//Using Lambda Expressions ->
		Drawable dob = ()->{
			System.out.println("Draw Method body");
		};
		dob.draw();
		
		//Thread Class Runnable interface
		
		Runnable rob = ()->{
			System.out.println("Run method is called");
		};
		Thread tob = new Thread(rob);
		tob.start();

}

}
