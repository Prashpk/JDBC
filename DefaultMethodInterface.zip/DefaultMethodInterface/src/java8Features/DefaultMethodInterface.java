package java8Features;

//java 8 feature default and static methods in interface

interface Calculations{
	void add(int a, int b); // -> Abstract method
	
	default void mul(int i,int j) { // -> non abstract & default method
		int s = i * j;
		System.out.println("product = "+s);
	}
	
	static void sub(int i,int j) { // -> static methods cannot be Inherited
		                           //static methods belongs to the interface itself
		int s = i - j;
		System.out.println("difference = "+s);
	}
}

interface Divide{
	default void div(int i,int j) { // -> non abstract & default method
		int s = i / j;
		System.out.println("Divided Value = "+s);
	}
	
	static void Reminder(int i,int j) { // -> static methods cannot be Inherited
		                           //static methods belongs to the interface itself
		int s = i % j;
		System.out.println("Reminder = "+s);
	}
	
	void myfunc();
}

public class DefaultMethodInterface implements Calculations, Divide{ //Multiple Interface

	@Override
	public void add(int a, int b) {//public is a must for abstract methods
		int s = a + b;
		System.out.println("Sum = "+s);
	}
	
	
	
	public static void main(String[] args) {
		DefaultMethodInterface ob = new DefaultMethodInterface();
		
		ob.add(5, 10);
		ob.mul(4, 5);
		//In order to call static methods call by interface not with object
		Calculations.sub(5, 8);

		//using another inherited interface methods
		ob.div(10, 5);
		Divide.Reminder(25,2);
		
		//Conflict solve in multiple inheritence
//		@Override
//		public void mul(int i,int j) {
//			Calculations.super.mul(i,j);
//			Divide.super.div(20,5);
//		}
//		
	}

	@Override
	public void myfunc() {
		System.out.println("I am function ");
		
	}
}
