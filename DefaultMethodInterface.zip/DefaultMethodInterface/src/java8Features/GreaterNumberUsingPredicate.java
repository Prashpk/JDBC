package java8Features;

import java.util.function.Predicate;

public class GreaterNumberUsingPredicate {

	public static void main(String[] args) {

		Predicate<Integer> ob = (i)-> i > 10;
//		System.out.println("is my number greater than " +ob.test(30));
		
		System.out.println("is my number greater than ");
		boolean b = ob.test(30);
		
		if(b) {
			System.out.println("greater than 10");
		}
		else {
			System.out.println("Less than 10");
		}

	}

}
