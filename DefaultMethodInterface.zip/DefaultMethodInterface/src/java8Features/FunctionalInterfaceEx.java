package java8Features;

import java.util.Scanner;
import java.util.function.Function;

public class FunctionalInterfaceEx {

	public static void main(String[] args) {
		
		Function<String,Integer> len = (str) -> str.length();
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter a String ");
		String s = sc.next();
		
		int i = len.apply(s);
		System.out.println("Length of the String is "+i);
				

	}

}
